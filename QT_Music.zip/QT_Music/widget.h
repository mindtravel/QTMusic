#ifndef WIDGET_H
#define WIDGET_H
#include "songOrder.h"
#include "mouse.h"
#include <songlist.h>

#include <QWidget>
#include <QLabel.h>
#include <QTimer.h>
#include <QMediaPlayer.h>
#include <QAudioOutput.h>
#include <qcompleter.h>
#include <QPushbutton.h>
#include <qcheckbox.h>

QT_BEGIN_NAMESPACE
namespace Ui { class Widget; }
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();

    QString path;
    QSize albumSize;
    QFont font;
    QMediaPlayer *player;
    QAudioOutput *audioOutput;
    QCompleter *qCompleter;
    QPixmap qPixmap;
    QPalette* qPalette;

    //右键菜单，用于将歌曲添加进歌单
    int selectedRow;
    void addRightMenu();
    //声明动作
    QAction* buttonAction;
    std::vector<QAction*> v;
    //声明菜单
    QMenu * buttonMenu;

    SongOrder songOrder{};//歌曲序号类
    SongList songList{};//歌单类

    //时间相关
    qint64 duration;//正在播放的歌曲的总时间
    qint64 positionNow;//正在播放的歌曲的当前时间
    QTimer timerSong;
    QTimer timer;

    void readSongs();
    void clearList();
    void openAlbumImage();
    void addSongIntoList();
    void addSongIntoListTemp();
    void getAlbumPosition();
    void setAlbumPosition(QPixmap& qPixmap);
    void movePage1();
    void setstackedWidget1();
    void playsong();
    void setSliderTime();
    void setPicture(QPushButton* p,int index);
    void setLabelFont(QLabel* p);
    void setManage(int index);
    void continueSong();
    void SearchSong(QString &str);
    int openSongListOp();
    int openDeleteCheck();
    void setSongList(QString str);
    void setTime();
    void openSongList(int index);
    void timeOp();
    int test();
private slots:
    void on_pushButton_clicked();

    void on_pushButtonSearch_clicked();

//    void on_tableWidget_cellChanged(int row, int column);

//    void on_toolBox_currentChanged(int index);

    void on_toolBox_currentChanged(int index);

    void on_tableWidget_cellDoubleClicked(int row, int column);

    void on_pushButtonPlayorStop_clicked();

    void on_horizontalSliderTime_sliderMoved(int position);

    void on_pushButtonLastSong_clicked();

    void on_pushButtonNextSong_clicked();

    void on_verticalSlider_sliderMoved(int position);

    void on_comboBoxPlayMode_currentIndexChanged(int index);

    void on_verticalSliderVolume_sliderMoved(int position);
    void on_comboBoxPlayMode_activated(int index);

    void on_pushButtonManage_clicked();

    void on_tableWidget_cellClicked(int row, int column);

    void on_tableWidgetSongList_cellClicked(int row, int column);

    void on_tableWidget_cellEntered(int row, int column);

    void on_tableWidget_cellActivated(int row, int column);

public:
    Ui::Widget *ui;
};
#endif // WIDGET_H
