#ifndef DIALOGSONGOP_H
#define DIALOGSONGOP_H

#include <QDialog>
#include <vector>
#include <QString>
#include<QAction>
#include<QMenu>
namespace Ui {
class DialogSongOp;
}

class DialogSongOp : public QDialog
{
    Q_OBJECT

public:
    explicit DialogSongOp(QWidget *parent = nullptr);
    void showList(std::vector<QString> v);
    ~DialogSongOp();

private:
    Ui::DialogSongOp *ui;
};

#endif // DIALOGSONGOP_H
