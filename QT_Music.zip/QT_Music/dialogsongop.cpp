#include "dialogsongop.h"
#include "ui_dialogsongop.h"
#include <QPushbutton>
DialogSongOp::DialogSongOp(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogSongOp)
{
    ui->setupUi(this);
    setWindowFlags(Qt::FramelessWindowHint);
};

DialogSongOp::~DialogSongOp(){
    delete ui;
}

void DialogSongOp::showList(std::vector<QString> v){
    int index=0;
    for(auto i:v){
        ui->tableWidget->insertRow(index);
        QTableWidgetItem *item0=new QTableWidgetItem(i);
        ui->tableWidget->setItem(index,0,item0);
    }
}
