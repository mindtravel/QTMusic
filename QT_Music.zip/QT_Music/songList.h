#ifndef SONGLIST_H
#define SONGLIST_H

#include<vector>
#include<list>
#include<fstream>
#include<QString>
#include<QFile>
#include<QDir>
#include<QTableWidget>
#include<QPushButton>
#include<QApplication>
class OneList{
public:
    //歌单的名称
    QString name;
    //歌单文件的地址
    std::string nameAddress;
    //歌曲信息
    std::list<int> song;
//    //文件操作对象
//    std::ofstream outfile;
//    std::ifstream infile;
    //初始化文件
    void initFile(bool flag){
        std::ofstream outfile;
        if(flag==true){
            outfile.open(nameAddress);
            outfile.close();
        }
        std::ifstream infile;
        infile.open(nameAddress);
        infile.seekg(0, std::ios::end); // 将文件指针移到文件末尾
        if (infile.tellg() == 0){
            infile.close();
            outfile.open(nameAddress);
            outfile<<"-1";
            outfile.close();
            //qDebug() << "文件为空" ;
        }
        else{
            //qDebug() << "文件不为空" ;
            infile.close();
        }

    }
    //写文件
    void writeFile(){
        std::ofstream outfile;
        outfile.open(nameAddress);
        for(auto i:song){
            outfile<<i<<std::endl;
        }
        outfile<<"-1";
        outfile.close();
    }
    //读文件
    void readFile(){
        std::ifstream infile;
        infile.open(nameAddress);
        int s=0;
        while(1){
            infile>>s;
            if(s==-1)break;
            //qDebug()<<s;
            song.push_back(s);
        }
        infile.close();
    }
    //向歌单中添加歌曲，并更新文件
    void addSong(int index){
        qDebug()<<"添加歌曲:"<<name<<" "<<index;
        song.push_back(index);
        writeFile();
    }
    //获取歌单名称
    QString getName(){
        return name;
        //qDebug()<<name;
    }
    //构造函数
    OneList(QString _name,bool flagNew=false):name(_name){
        nameAddress="../QT_Music/data/songLists/"+name.toStdString()+".txt";
        initFile(flagNew);
        readFile();
    }
//    OneList(OneList &a){
//        name=a.name;
//        song=a.song;
//    }
    //展示歌单内歌曲，并更新文件
    std::vector<int> showList(){
        //for(auto )
        song.sort();
        song.unique();
        writeFile();//整理歌曲

        std::vector<int> v;
        for(auto i:song){
            v.push_back(i);
            qDebug()<<i;
        }
        return v;
    }
};

class SongList{
public:
    std::vector<OneList> l;
    std::string nameAddress;
    std::string deleteAddress;
    std::list<int> deleted;
//    std::ofstream outfile;
//    std::ifstream infile;
    int isManage;
    //降序比较器
    bool static comp(int a,int b){
        return a>=b;
    }
    bool static compstr(OneList a,OneList b){
        return a.name>=b.name;
    }
    //写文件
    void writeFile(){
        std::ofstream outfile;
        //将deleted排序，序号小的在尾部
        deleted.sort(comp);
        for(auto i:deleted){
            qDebug()<<i;
        }
        //写入歌单文件
        outfile.open(nameAddress);
        for(auto i:l){
            outfile<<i.getName().toStdString()<<std::endl;
        }
        outfile<<"-1";
        outfile.close();
        //写入deleted.txt
        outfile.open(deleteAddress);
        for(auto i:deleted){
            outfile<<i<<std::endl;
            qDebug()<<i;
        }
        outfile<<"-1";
        outfile.close();
    }
    //删除歌曲
    void writeFileDelete(){
        std::ofstream outfile;
        //将deleted排序，序号小的在尾部
        deleted.sort(comp);
        for(auto i:deleted){
            qDebug()<<i;
        }
        //按照deleted.txt中的编号删除文件
        outfile.open(nameAddress);
        int index=0;
        std::string s="";
        for(auto i:l){
            if(!deleted.empty()&&index==deleted.back()){
                qDebug()<<"deleted.size()="<<deleted.size();
                deleted.pop_back();
                index++;
                continue;
            }
            s=i.getName().toStdString();
            outfile<<s<<std::endl;
            index++;
        }
        outfile<<"-1";
        outfile.close();
        //初始化deleted.txt
        outfile.open(deleteAddress);
        outfile<<"-1";
        outfile.close();
    }
    //读文件
    void readFile(){
        qDebug()<<"读文件";
        l.clear();
        deleted.clear();
        std::ifstream infile;
        infile.open(nameAddress);
        std::string s="";
        while(1){
            infile>>s;
            if(s=="-1")break;
            qDebug()<<s;
            l.push_back(OneList(QString::fromStdString(s)));
        }
        infile.close();
        infile.open(deleteAddress);
        int i=0;
        while(1){
            infile>>i;
            if(i==-1)break;
            //qDebug()<<i;
            deleted.push_back(i);
        }
        infile.close();
    }
    //向歌单中添加歌曲
    void addSongList(QString str){
        l.push_back(OneList(str,true));
        //sort(l.begin(),l.end(),compstr);
        writeFile();
//        for(auto i:name){
//            qDebug()<<i;
//        }
    }
    //依据deleted中的序号，删除歌单
    void deleteSongList(){
        //readFile();
        deleted.sort(std::greater<int>());
        for(auto i:deleted){
            qDebug()<<i;
        }
        writeFileDelete();
        deleted.clear();
        //        for(auto i:name){
        //            qDebug()<<i;
        //        }
    }
    //向deleted中添加歌曲
    void addDeleted(int index){
        deleted.push_back(index);
//        for(auto i:deleted){
//            qDebug()<<i;
//        }
    }
    //将歌单展示在tablewidget中
    void showSongList(QTableWidget* t){
         t->clearContents();
         t->setRowCount(0);
         //sort(l.begin(),l.end(),compstr);
         int index=0;
         for(auto i:l){
             //qDebug()<<i;
             t->insertRow(index);
             QTableWidgetItem *item=new QTableWidgetItem(i.getName());
             t->setItem(index,0,item);
             index++;
         }
    }
    //展示index编号的歌单中的歌曲
    std::vector<int> showList(int index){
        return l[index].showList();
    }
    //设置管理挡位
    void setManage(int index){
        isManage=index;
    }
    //检查是否被删除
    int checkDeleted(int index){
         for(std::list<int>::iterator i=deleted.begin();i!=deleted.end();++i){
             if(*i==index){
                deleted.erase(i);
                return true;
             }
         }
         return false;
    }
    //定位到歌单中，然后添加歌曲
    void addSong(int SongListIndex,int songIndex){
         l[SongListIndex].addSong(songIndex);
         qDebug()<<SongListIndex<<" "<<songIndex;
    }
    //获取序号为index的歌单的名称
    QString getName(int index){
        return l[index].getName();
    }
    //构造函数，初始化文件
    SongList(){
         isManage=0;
         nameAddress="../QT_Music/data/allSongList.txt";
         deleteAddress="../QT_Music/data/deleteSongList.txt";
         readFile();
    }
    ~SongList(){}
};


#endif // SONGLIST_H
