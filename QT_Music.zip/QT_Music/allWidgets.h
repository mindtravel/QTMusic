#ifndef ALLWIDGETS_H
#define ALLWIDGETS_H
#include "widget.h"
#include "ui_widget.h"

#include "dialogdeletesonglist.h"
#include "ui_dialogdeletesonglist.h"

#include "dialognewsonglist.h"
#include "ui_dialognewsonglist.h"

#include "dialogquitcheck.h"
#include "ui_dialogquitcheck.h"

#include "widget.h"
#include "ui_widget.h"




#endif // ALLWIDGETS_H
