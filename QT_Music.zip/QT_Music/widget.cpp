#include "widget.h"
#include "ui_widget.h"

#include "dialogsonglistop.h"

#include "dialogdeletesonglist.h"

#include "dialogsongop.h"

#include "QTimer.h"
#include "dialogquitcheck.h"
#include <QVariantMap.h>
#include <QMediaMetaData.h>
#include <qfiledialog.h>
#include <list>
#include <mp3info.h>
#include <qmessagebox.h>
#include <qurl.h>
#include <QDesktopServices.h>

using namespace std;
//int numSongs=0;
extern int xPage1,yPage1;
QString textManage[2]={"管理","结束管理"};
QString pictureNames[6]={"background1.png","lastSong.png","nextSong.png","Play.png","Stop.png","album.png"};

vector<string> fileNames;
vector<Mp3Info> mp3Info_v;
vector<Mp3Info>::iterator mp3Info_vi;
QList<QString> songQSring_l;
QList<QString> allSongQSring_l;
vector<QString>::iterator allSongQSring_vi;
//在pushbutton上贴图
void Widget::setPicture(QPushButton* p,int index){
    QPalette palette = p->palette();
    p->setIcon(QIcon("../QT_Music/Pictures/"+pictureNames[index]));
    p->setPalette(palette);
    p->setIconSize(QSize(50,20));
    p->update();
}
//设置调色盘
void Widget::setLabelFont(QLabel* p){
    QPalette palette;
    p->setFont(font);
    palette.setColor(QPalette::WindowText, Qt::white);
    p->setPalette(palette);
}

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    //建立窗体
    ui->setupUi(this);
    // 创建一个QPalette对象
    setPicture(ui->pushButtonLastSong,1);
    setPicture(ui->pushButtonPlayorStop,3);
    setPicture(ui->pushButtonNextSong,2);
    //音频设置
    player = new QMediaPlayer(this);
    audioOutput = new QAudioOutput(this);
    audioOutput->setVolume(100);
    player->setAudioOutput(audioOutput);
    player->stop();
    duration=0Xffffffff;

    albumSize=QSize(200,200);
    //初始化窗口
    ui->toolBox->setCurrentIndex(0);

    // 初始化horizontalSliderTime
    ui->horizontalSliderTime->setRange(0, 1000);
    // 初始化verticalSliderVolume
    ui->verticalSliderVolume->setRange(0, 100);
    ui->verticalSliderVolume->setSliderPosition(50);
    //设置字体
    font.setFamily("Arial");
    font.setBold(true);
    font.setPointSize(12);
    setLabelFont(ui->labelSongTitle);
    setLabelFont(ui->labelSongAuthor);
    setLabelFont(ui->labelSongAlbum);
    setLabelFont(ui->labelSongSource);
    font.setPointSize(10);
    setLabelFont(ui->labelTitle);
    setLabelFont(ui->labelAuthor);
    setLabelFont(ui->labelAlbum);
    setLabelFont(ui->labelSource);
    font.setPointSize(10);
    setLabelFont(ui->label);
    setLabelFont(ui->labelListTitle);
    setLabelFont(ui->labelSongList);
    setLabelFont(ui->labelTime);

    path="../QT_Music/Pictures/"+pictureNames[0];
    qPalette=new QPalette(this->palette());

    qPixmap=QPixmap(path);
    qPalette->setBrush(QPalette::Window, qPixmap);
    this->setAutoFillBackground(true);
    this->setPalette(*qPalette);
    //初始化调色盘

    songList.showSongList(ui->tableWidgetSongList);
    setManage(0);
    //设置TableWidgetSongList
    ui->tableWidgetSongList->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->tableWidgetSongList->verticalHeader()->setSectionResizeMode(QHeaderView::Fixed);

    //设置TableWidget
    ui->tableWidget->setContextMenuPolicy(Qt::CustomContextMenu);
    ui->tableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->tableWidget->verticalHeader()->setSectionResizeMode(QHeaderView::Fixed);
    ui->tableWidget->setColumnWidth(0, 50);
    ui->tableWidget->setColumnWidth(5, 40);
    //设置RightMenu
    buttonMenu = new QMenu();
    selectedRow=-1;
    connect(ui->tableWidget, &QTableWidget::customContextMenuRequested, [=](const QPoint& pos) {
        QModelIndex index = ui->tableWidget->indexAt(pos);
        selectedRow = index.row();
        qDebug() << "Selected Row: " << selectedRow;
        if(selectedRow!=-1)buttonMenu->exec(QCursor::pos());
    });
    clearList();


    //激活timer
    timeOp();
}
//析构函数
Widget::~Widget()
{
    delete player;
    delete audioOutput;
    delete ui;
}


void Widget::readSongs(){
    //初始化文件路径数组
    QMediaPlayer *p = new QMediaPlayer(this);
    QAudioOutput *au = new QAudioOutput(this);
    p->setAudioOutput(au);

    getFileNames("../QT_Music/music", fileNames);
    //初始化MP3信息数组
    Mp3Info temp;
    for (const auto &ph : fileNames) {
        //qDebug() <<ph;
        temp.getInfo(ph);
        p->setSource(QUrl::fromLocalFile(correctQString(ph)));
        temp.writeDuration(p->duration());
        mp3Info_v.push_back(temp);
        //qDebug()<<temp.getQDuration();
    }
    //初始化所有歌曲数组
    //导入所有歌曲至allSongQSring_v
    int id=0;
    for(mp3Info_vi=mp3Info_v.begin();mp3Info_vi!=mp3Info_v.end();++mp3Info_vi){
        //mp3Infovi->printInfo();
        //qDebug() <<"debug:  "<<mp3Info_vi->getQTitle();
        allSongQSring_l.push_back(mp3Info_vi->getQTitle());
        mp3Info_vi->writeId(id);
        id++;
    }
    //初始化自动填充lineEditSearch
    qCompleter=new QCompleter(allSongQSring_l,this);
    qCompleter->setCaseSensitivity(Qt::CaseInsensitive);
    ui->lineEditSearch->setCompleter(qCompleter);
}
//与时间挂钩的所有操作
void Widget::timeOp(){
    timer.setInterval(20);  // 每20ms触发一次
    timer.start();
    // 连接定时器的timeout()信号到槽函数
    QObject::connect(&timer, &QTimer::timeout, [&]() {
        //if(!image.isNull()){
        getAlbumPosition();
        movePage1();
        continueSong();
        setSliderTime();
        setTime();
        //qDebug() << "xAlbum="<<xAlbum<<"    yAlbum="<<yAlbum;
    });
}
//获得专辑图片的坐标信息
void Widget::getAlbumPosition()
{
    //    int width=this->width();
    int height=this->height();
    xPage1=(ui->pushButtonPlayorStop->pos().x()+ui->pushButtonPlayorStop->pos().rx())/4;
    yPage1=height/4;
}
//设置图片位置大小数据
void Widget::setAlbumPosition(QPixmap& qPixmap)
{
    qPixmap=qPixmap.scaled(albumSize, Qt::KeepAspectRatio);
    ui->labelAlbumImage->setPixmap(qPixmap);
    ui->labelAlbumImage->adjustSize();
}
//打开图片
void Widget::openAlbumImage(){
    QString imagePath ="../QT_Music/Pictures/"+pictureNames[5];
    if (!imagePath.isEmpty()) {
        QPixmap qPixmap(imagePath);
        if (qPixmap.isNull()) {
            QMessageBox::information(this, tr("错误"), tr("无法加载图片."));
            return;
        }
        setAlbumPosition(qPixmap);
    }
}
//实时移动Page1中组件
void Widget::movePage1(){
    ui->labelTitle->move(xPage1-110,yPage1+115);
    ui->labelAuthor->move(xPage1+100,yPage1+10);
    ui->labelAlbum->move(xPage1+100,yPage1-40);
    ui->labelSource->move(xPage1+100,yPage1-90);

    ui->labelAlbumImage->move(xPage1-120,yPage1-100);
    ui->labelSongTitle->move(xPage1-60,yPage1+100);
    ui->labelSongAuthor->move(xPage1+150,yPage1);
    ui->labelSongAlbum->move(xPage1+150,yPage1-50);
    ui->labelSongSource->move(xPage1+150,yPage1-100);

    ui->tableWidget->resize(this->width(),this->height()-120);
}
//将tableWidget清空
void Widget::clearList(){
    ui->tableWidget->clearContents();
    ui->tableWidget->setRowCount(0);
    return;
}
//将正在播放的歌曲添加到tableWidget中
void Widget::addSongIntoList(){
    for(int i=0;i<songOrder.getNum();++i){
        //row=ui->tableWidget->rowCount();
        ui->tableWidget->insertRow(i);
        QTableWidgetItem *item0=new QTableWidgetItem(mp3Info_v[songOrder.getSong(i)].getQDuration());
        ui->tableWidget->setItem(i,0,item0);
        QTableWidgetItem *item1=new QTableWidgetItem(mp3Info_v[songOrder.getSong(i)].getQTitle());
        ui->tableWidget->setItem(i,1,item1);
        QTableWidgetItem *item2=new QTableWidgetItem(mp3Info_v[songOrder.getSong(i)].getQAuthor());
        ui->tableWidget->setItem(i,2,item2);
        QTableWidgetItem *item3=new QTableWidgetItem(mp3Info_v[songOrder.getSong(i)].getQType());
        ui->tableWidget->setItem(i,3,item3);
        QTableWidgetItem *item4=new QTableWidgetItem(mp3Info_v[songOrder.getSong(i)].getQAlbum());
        ui->tableWidget->setItem(i,4,item4);
        QTableWidgetItem *item5=new QTableWidgetItem(mp3Info_v[songOrder.getSong(i)].getQYear());
        ui->tableWidget->setItem(i,5,item5);
        qDebug()<<"row="<<i;
    }
    return;
}
//将不正在播放的歌曲添加到tableWidget中
void Widget::addSongIntoListTemp(){
    for(int i=0;i<songOrder.getNumTemp();++i){
        //row=ui->tableWidget->rowCount();
        ui->tableWidget->insertRow(i);
        QTableWidgetItem *item0=new QTableWidgetItem(mp3Info_v[songOrder.getSongTemp(i)].getQDuration());
        ui->tableWidget->setItem(i,0,item0);
        QTableWidgetItem *item1=new QTableWidgetItem(mp3Info_v[songOrder.getSongTemp(i)].getQTitle());
        ui->tableWidget->setItem(i,1,item1);
        QTableWidgetItem *item2=new QTableWidgetItem(mp3Info_v[songOrder.getSongTemp(i)].getQAuthor());
        ui->tableWidget->setItem(i,2,item2);
        QTableWidgetItem *item3=new QTableWidgetItem(mp3Info_v[songOrder.getSongTemp(i)].getQType());
        ui->tableWidget->setItem(i,3,item3);
        QTableWidgetItem *item4=new QTableWidgetItem(mp3Info_v[songOrder.getSongTemp(i)].getQAlbum());
        ui->tableWidget->setItem(i,4,item4);
        QTableWidgetItem *item5=new QTableWidgetItem(mp3Info_v[songOrder.getSongTemp(i)].getQYear());
        ui->tableWidget->setItem(i,5,item5);
        qDebug()<<"row="<<i;
    }
    return;
}
//搜索框
void Widget::SearchSong(QString &str){
    vector<int> v;
    for(mp3Info_vi=mp3Info_v.begin();mp3Info_vi!=mp3Info_v.end();++mp3Info_vi){
        if(str==mp3Info_vi->getQTitle()){
            v.push_back(mp3Info_vi->getId());
            songOrder.setOrderTemp(v);
            songOrder.setSourceTemp(str+"的搜索结果");
            ui->labelListTitle->setText(str+"的搜索结果");
            str="";
            //qDebug()<<*songNum_vi;
            return;
        }
    }
    songOrder.setOrderTemp(v);
    songOrder.setSourceTemp(str+"的搜索结果");
    ui->labelListTitle->setText(str+"的搜索结果");
    str="";
    return;
}
//搜索
void Widget::on_pushButtonSearch_clicked(){
    QString str=ui->lineEditSearch->text();
    if(str!=""){
        ui->stackedWidget->setCurrentIndex(1);
        clearList();
        SearchSong(str);
        if(mp3Info_vi!=mp3Info_v.end()){
            addSongIntoListTemp();
        }
    }
    ui->lineEditSearch->setText("");
}
//歌单管理
int Widget::openSongListOp(){
    DialogSongListOp d;
    d.show();
    this->close();
    return d.exec();
}
//确认要删除歌单
int Widget::openDeleteCheck(){
    DialogDeleteSongList d;
    d.show();
    this->close();
    return d.exec();
}
//从toolbox中检索
void Widget::on_toolBox_currentChanged(int index)
{
    if(index==0){
        ui->stackedWidget->setCurrentIndex(0);
    }
    //导入所有歌曲至songList
    if(index==1){
        clearList();
        ui->stackedWidget->setCurrentIndex(1);
        ui->labelListTitle->setText("所有歌曲");
        vector<int> v;
        for(mp3Info_vi=mp3Info_v.begin();mp3Info_vi!=mp3Info_v.end();++mp3Info_vi){
            v.push_back(mp3Info_vi->getId());
        }
        songOrder.setOrderTemp(v);
        songOrder.setSourceTemp("所有歌曲");
        addSongIntoListTemp();
        //qDebug()<<songOrder.getNum();
    }
    //打开歌曲文件夹，可在其中
    if(index==2){
        clearList();
        ui->stackedWidget->setCurrentIndex(1);
        ui->labelListTitle->setText(songOrder.getSource());
        addSongIntoList();
    }
    if(index==3){
        clearList();
        QString filePath="../QT_Music/music";
        QUrl qUrl = QUrl::fromLocalFile(filePath);
        QDesktopServices::openUrl(qUrl);
    }
}
//设置pushbuttonmanage挡位
void Widget::setManage(int index){
    songList.setManage(index);
    ui->pushButtonManage->setText(textManage[index]);
}
//pushButtonManage
void Widget::on_pushButtonManage_clicked(){
    player->pause();//管理时，不能播放歌曲
    if(songList.isManage==0){
        qDebug()<<"挡位0";
        songList.writeFile();
        clearList();
        openSongListOp();
    }
    if(songList.isManage==1){
        qDebug()<<"挡位1";
        songList.writeFile();
        openDeleteCheck();
        ui->tableWidgetSongList->removeColumn(1);
        songList.showSongList(ui->tableWidgetSongList);
    }
}
//选中需要删除的歌单
void Widget::on_tableWidgetSongList_cellClicked(int row, int column)
{
    if(column==0){
        ui->stackedWidget->setCurrentIndex(1);
        clearList();
        ui->labelListTitle->setText("歌单："+songList.getName(row));
        songOrder.setOrderTemp(songList.showList(row));
        songOrder.setSourceTemp("歌单："+songList.getName(row));
        addSongIntoListTemp();

    }
    if(column==1){
        QTableWidgetItem *item = new QTableWidgetItem();
        if(songList.checkDeleted(row)){
            item->setBackground(Qt::white);
        }
        else{
            item->setBackground(Qt::black);
            songList.addDeleted(row);
        }
        ui->tableWidgetSongList->setItem(row,1,item);
    }
}
//播放歌曲
void Widget::playsong(){
    qDebug()<<"播放";
    player->stop();
    player->setSource(QUrl::fromLocalFile(correctQString(fileNames[songOrder.getAtPlay()])));
    player->setPosition(0);
    player->play();
    duration = player->duration();
    qDebug()<<"atPlay:"<<songOrder.getAtPlay();//<<" listPlay:"<<orderPlay;
    //qDebug()<<duration;-
}
//设置stackedwidget1样式
void Widget::setstackedWidget1(){
    ui->stackedWidget->setCurrentIndex(0);
    ui->toolBox->setCurrentIndex(0);
    ui->labelSongTitle->setText((mp3Info_v.begin()+songOrder.getAtPlay())->getQTitle());
    ui->labelSongAuthor->setText((mp3Info_v.begin()+songOrder.getAtPlay())->getQAuthor());
    ui->labelSongAlbum->setText((mp3Info_v.begin()+songOrder.getAtPlay())->getQAlbum());
    ui->labelSongSource->setText(songOrder.getSource());
}
//调出歌单列表
void Widget::setSongList(QString str){
    songList.addSongList(str);
    songList.showSongList(ui->tableWidgetSongList);
}
//当tablewidget各栏被点击时，用对应的方式检索歌曲
void Widget::on_tableWidget_cellDoubleClicked(int row, int column)
{
    if(column==0){
        //ui->labelQTMusic->setText("play");
        setPicture(ui->pushButtonPlayorStop,4);
        songOrder.setOrder(row);
        songOrder.setPlayMode(ui->comboBoxPlayMode->currentIndex());
        playsong();
        setstackedWidget1();
        openAlbumImage();
    }
    if(column==1){
        //ui->labelQTMusic->setText("seclect artist");
    }
    if(column==2){
        //ui->labelQTMusic->setText("select song/backup");
    }
    if(column==3){
        //ui->labelQTMusic->setText("select style");
    }
    if(column==4){
        //ui->labelQTMusic->setText("select album");
    }
}
//连续播放歌曲
void Widget::continueSong(){
    if(player->position()>=duration){
        qDebug()<<"换歌";
        songOrder.nextSong();
        setstackedWidget1();
        playsong();
    }
}
//播放暂停按键
void Widget::on_pushButtonPlayorStop_clicked()
{
    if(!songOrder.getVEmpty()){
        if(player->isPlaying()==1){
            setPicture(ui->pushButtonPlayorStop,3);
            player->pause();
        }
        else{
            setPicture(ui->pushButtonPlayorStop,4);
            timerSong.start(1000);
            player->play();
        }
    }

}
//上一首按键
void Widget::on_pushButtonLastSong_clicked(){
    if(!songOrder.getVEmpty()){
        songOrder.lastSong();
        setstackedWidget1();
        playsong();
    }
}
//下一首按键
void Widget::on_pushButtonNextSong_clicked()
{
    if(!songOrder.getVEmpty()){
        songOrder.nextSong();
        setstackedWidget1();
        playsong();
        //qDebug()<<atPlay;
    }
}
//歌曲->进度条
void Widget::setSliderTime(){
    positionNow = player->position(); // 获取当前播放位置（毫秒）
    ui->horizontalSliderTime->setValue(positionNow*1000/duration); // 设置滑块的范围
}
//进度条->歌曲
void Widget::on_horizontalSliderTime_sliderMoved(int position)
{
    player->setPosition(position*duration/1000);
    player->play();
}
//计算并输出播放时间
void Widget::setTime()
{
    int m,s,mSum,sSum,pTemp=0,dTemp=0;
    pTemp = positionNow/1000;  //获得的时间是以毫秒为单位的
    m = pTemp/60;
    s = pTemp-m*60;
    dTemp = duration/1000;
    mSum = dTemp/60;
    sSum = dTemp-mSum*60;
    ui->labelTime->setText(QString("%1:%2/%3:%4").arg(m, 2, 10, QLatin1Char('0')).arg(s, 2, 10, QLatin1Char('0')).arg(mSum, 2, 10, QLatin1Char('0')).arg(sSum, 2, 10, QLatin1Char('0')));  //把int型转化为string类型后再设置为label的text
}
//调节音量
void Widget::on_verticalSliderVolume_sliderMoved(int position)
{
    audioOutput->setVolume(position);
    player->setAudioOutput(audioOutput);
    //qDebug()<<position;
}
//退出主界面
void Widget::on_pushButton_clicked(){
    DialogQuitCheck dlgQuitCheck;
    if(dlgQuitCheck.exec() == QDialog:: Accepted)
        close();
}
//点击comboBox对应的栏，设置播放方式
void Widget::on_comboBoxPlayMode_activated(int index)
{
    songOrder.setPlayMode(index);
}
//将歌单中歌曲显示在tablewidget上，但是不更新播放队列
void Widget::openSongList(int index){
    ui->stackedWidget->setCurrentIndex(1);
    ui->labelListTitle->setText(songList.l[index].getName());
    clearList();
}
//将歌单选项加入rightmenu
void Widget::addRightMenu(){
    int index=0;
    for(auto i:songList.l){
        buttonAction = new QAction(i.getName(),this);
        v.push_back(buttonAction);
        buttonMenu->addAction(v.back());
        connect( v.back(), &QAction::triggered, [=]()
            {
                qDebug()<<"加入歌单 编号："<<index<<" 名称"<<i.name<<" 歌曲"<<songOrder.getSong(selectedRow);
                songList.addSong(index,songOrder.getSongTemp(selectedRow));
            });
        index++;
    }
}
//测试某些功能
int Widget::test(){
    DialogSongOp d;
    d.show();
    return d.exec();
}
//废弃槽
void Widget::on_tableWidget_cellEntered(int row, int column){
}
void Widget::on_tableWidget_cellActivated(int row, int column){
}
void Widget::on_comboBoxPlayMode_currentIndexChanged(int index){
}
void Widget::on_verticalSlider_sliderMoved(int position){
}
void Widget::on_tableWidget_cellClicked(int row, int column)
{
}
