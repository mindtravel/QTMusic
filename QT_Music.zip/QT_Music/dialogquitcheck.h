#ifndef DIALOGQUITCHECK_H
#define DIALOGQUITCHECK_H

#include <QDialog>

namespace Ui {
class DialogQuitCheck;
}

class DialogQuitCheck : public QDialog
{
    Q_OBJECT

public:
    explicit DialogQuitCheck(QWidget *parent = nullptr);
    ~DialogQuitCheck();

private:
    Ui::DialogQuitCheck *ui;
};

#endif // DIALOGQUITCHECK_H
