#include "dialogsonglistop.h"
#include "ui_dialogsonglistop.h"

#include "widget.h"
#include "ui_widget.h"

#include "dialognewsonglist.h"

DialogSongListOp::DialogSongListOp(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogSongListOp)
{
    //connect(this, SIGNAL(pushButtonNewSongList_clicked()), SLOT(pushButtonNewSongList_isclicked()));
    ui->setupUi(this);
    setWindowFlags(Qt::FramelessWindowHint);
}

DialogSongListOp::~DialogSongListOp()
{

    delete ui;
}

int DialogSongListOp::newSongListOp(){
    DialogNewSongList d;
    d.show();
    this->close();
    return d.exec();
}

void DialogSongListOp::deleteSongListOp(){
    //新建widget窗口对象
    Widget* w=new Widget(this->parentWidget());
    w->addRightMenu();
    //设置tableWidgetSongList
    w->ui->tableWidgetSongList->insertColumn(1);
    w->ui->tableWidgetSongList->setHorizontalHeaderLabels(QStringList() << "名称" << "删除");
    w->ui->tableWidgetSongList->setColumnWidth(1, 30);

    w->setManage(true);
    w->show();
}

void DialogSongListOp::on_pushButtonNewSongList_clicked()
{
    this->close();
    newSongListOp();
}


void DialogSongListOp::on_pushButtonDeleteSongList_clicked()
{
    this->close();
    deleteSongListOp();
}


void DialogSongListOp::on_pushButtonQuit_clicked()
{
    this->close();
    Widget* w=new Widget(this->parentWidget());
    w->addRightMenu();
    w->show();
}

